"use strict";

module.exports = {};