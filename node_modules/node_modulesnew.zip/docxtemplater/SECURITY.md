# Security Policy

## Supported Versions

The latest 3.x version of docxtemplater is the one that will be supported.

This version will have security bugfixes until at least 31/12/2025.

## Reporting a Vulnerability

To report a vulnerability, please use the "contact us" button on https://docxtemplater.com/

You should get an update on the reported vulnerability within 48 hours.

The fix will come in quickly, within one week.
