module.exports = {
	rules: {
		"specific-sort": require("./sortable.js"),
	},
};
