/* !

PizZipUtils - A collection of cross-browser utilities to go along with PizZip.

(c) 2014 Stuart Knightley, David Duponchel
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/open-xml-templating/pizzip/master/LICENSE.markdown.

*/
