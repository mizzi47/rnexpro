v0.0.2 2014-05-19
=================

-	Drop the code for xhr on `file://` and fix an issue with `file://` to `http://` requests

v0.0.1 2014-04-27
=================

-	First release.
