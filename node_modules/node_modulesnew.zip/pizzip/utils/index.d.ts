declare var PizZipUtils : {
  getBinaryContent(path: string, callback: (err: Error, data: string) => void) : void
}

export default PizZipUtils;
