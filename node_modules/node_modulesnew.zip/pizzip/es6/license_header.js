/* !

PizZip - A Javascript class for generating and reading zip files
<https://github.com/open-xml-templating/pizzip>

(c) 2009-2014 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/open-xml-templating/pizzip/master/LICENSE.markdown

PizZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/master/LICENSE
*/
