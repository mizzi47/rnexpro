#!/usr/bin/env sh

rm -rf utils/node_modules
cp -r node_modules utils/node_modules
